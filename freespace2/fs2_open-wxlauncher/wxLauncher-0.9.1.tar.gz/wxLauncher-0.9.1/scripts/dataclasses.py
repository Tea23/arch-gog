class Tag:
  def __init__(self, name, attrs, data=None):
    self.name = name
    self.attributes = attrs
    self.data = data